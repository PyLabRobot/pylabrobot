import time, json, signal, os, requests, string, logging, subprocess, win32gui, win32con
from http import server
from threading import Thread
from multiprocessing import Process
from pyhamilton import OEM_RUN_EXE_PATH, OEM_HSL_PATH
from .oemerr import *#HamiltonTimeoutError, HamiltonError, HAMILTON_ERROR_MAP
from .defaultcmds import defaults_by_cmd
    
class HamiltonCmdTemplate:
        
    @staticmethod
    def unique_id():
        return hex(int((time.time()%3600e4)*1e6))

    def __init__(self, cmd_name, params_list):
        self.cmd_name = cmd_name
        self.params_list = params_list
        if cmd_name in defaults_by_cmd:
            const_name, default_dict = defaults_by_cmd[cmd_name]
            self.defaults = {k:v for k, v in default_dict.items() if v is not None}
        else:
            self.defaults = {}

    def assemble_cmd(self, *args, **kwargs):
        if args:
            raise ValueError('assemble_cmd can only take keyword arguments.')
        assembled_cmd = {'command':self.cmd_name, 'id':HamiltonCmdTemplate.unique_id()}
        assembled_cmd.update(self.defaults)
        assembled_cmd.update(kwargs)
        self.assert_valid_cmd(assembled_cmd)
        return assembled_cmd

    def assert_valid_cmd(self, cmd_dict):
        prefix = 'Assert valid command "' + self.cmd_name + '" failed: '
        if 'id' not in cmd_dict:
            raise ValueError(prefix + 'no key "id"')
        if 'command' not in cmd_dict:
            raise ValueError(prefix + 'no key "command"')
        if cmd_dict['command'] != self.cmd_name:
            raise ValueError(prefix + 'command name "' + cmd_dict['command'] + '" does not match')
        needs = set(['command', 'id'])
        needs.update(self.params_list)
        givens = set(cmd_dict.keys())
        if givens != needs:
            raise ValueError(prefix + 'template parameter keys ' + str(sorted(list(needs))) +
                    ' do not match given keys ' + str(sorted(list(givens))))

_builtin_templates_by_cmd = {}

for cmd in defaults_by_cmd:
    const_name, default_dict = defaults_by_cmd[cmd]
    const_template = HamiltonCmdTemplate(cmd, list(default_dict.keys()))
    globals()[const_name] = const_template
    _builtin_templates_by_cmd[cmd] = const_template

def _make_new_hamilton_serv_handler(resp_indexing_fn):
    class HamiltonServerHandler(server.BaseHTTPRequestHandler):
        _send_queue = []
        indexed_responses = {}
        indexing_fn = resp_indexing_fn
        MAX_QUEUED_RESPONSES = 1000

        @staticmethod
        def send_str(cmd_str):
            if not isinstance(cmd_str, b''.__class__):
                if isinstance(cmd_str, ''.__class__):
                    cmd_str = cmd_str.encode()
                else:
                    raise ValueError('send_command can only send strings, not ' + str(cmd_str))
            HamiltonServerHandler._send_queue.append(cmd_str)

        @staticmethod
        def has_queued_cmds():
            return bool(HamiltonServerHandler._send_queue)

        @staticmethod
        def pop_response(idx):
            ir = HamiltonServerHandler.indexed_responses
            if idx not in ir:
                raise KeyError('No response received with index ' + str(idx))
            return ir.pop(idx).decode()
        
        def _set_headers(self):
            self.send_response(200)
            self.send_header('Content-type', 'text/HTML')
            self.end_headers()

        def do_GET(self):
            sq = HamiltonServerHandler._send_queue
            response_to_send = sq.pop(0) if sq else b''
            self._set_headers()
            self.wfile.write(response_to_send)

        def do_HEAD(self):
            self._set_headers()
            
        def do_POST(self):
            content_len = int(self.headers.get('content-length', 0))
            post_body = self.rfile.read(content_len)
            self._set_headers()
            self.wfile.write(b'<html><body><h1>POST!</h1></body></html>')
            ir = HamiltonServerHandler.indexed_responses
            index = HamiltonServerHandler.indexing_fn(post_body)
            if index is None:
                return
            ir[index] = post_body

    return HamiltonServerHandler

def run_hamilton_process():
    import clr
    from pyhamilton import OEM_STAR_PATH, OEM_HSL_PATH
    clr.AddReference(os.path.join(OEM_STAR_PATH, 'RunHSLExecutor'))
    clr.AddReference(os.path.join(OEM_STAR_PATH, 'HSLHttp'))
    from RunHSLExecutor import Class1
    C = Class1()
    C.StartMethod(OEM_HSL_PATH)
    try:
        while True:
            pass # Send external signal to end process
    except:
        pass

_block_numfield = 'Num'
_block_mainerrfield = 'MainErr'
BLOCK_FIELDS = _block_numfield, _block_mainerrfield, 'SlaveErr', 'RecoveryBtnId', 'StepData', 'LabwareName', 'LabwarePos'
_block_field_types = int, int, int, int, str, str, str

class HamiltonInterface:

    known_templates = _builtin_templates_by_cmd
    default_port = 3221
    default_address = '127.0.0.1' # localhost

    class HamiltonServerThread(Thread):

        def __init__(self, address, port):
            Thread.__init__(self)
            self.server_address = (address, port)
            self.should_continue = True
            self.exited = False
            def index_on_resp_id(response_str):
                try:
                    response = json.loads(response_str)
                    if 'id' in response:
                        return response['id']
                    return None
                except json.decoder.JSONDecodeError:
                    return None
            self.server_handler_class = _make_new_hamilton_serv_handler(index_on_resp_id)
            self.httpd = None

        def run(self):
            self.exited = False
            self.httpd = server.HTTPServer(self.server_address, self.server_handler_class)
            while self.should_continue:
                self.httpd.handle_request()
            self.exited = True

        def disconnect(self):
            self.should_continue = False

        def has_exited(self):
            return self.exited

    def __init__(self, address=None, port=None, simulate=False):
        self.address = HamiltonInterface.default_address if address is None else address
        self.port = HamiltonInterface.default_port if port is None else port
        self.simulate = simulate
        self.server_thread = None
        self.oem_process = None
        self.active = False
        self.logger = None
        self.log_queue = []

    def start(self):
        if self.active:
            return
        self.log('starting a Hamilton interface')
        if self.simulate:
            sim_window_handle = None
            try:
                sim_window_handle = win32gui.FindWindow(None, 'Hamilton Run Control - ' + os.path.basename(OEM_HSL_PATH))
            except win32gui.error:
                pass
            if sim_window_handle:
                try:
                    win32gui.SendMessage(sim_window_handle, win32con.WM_CLOSE, 0, 0)
                    os.system('taskkill /f /im HxRun.exe')
                except win32gui.error:
                    self.stop()
                    self.log_and_raise(OSError('Simulator already open'))
            subprocess.Popen([OEM_RUN_EXE_PATH, OEM_HSL_PATH])
            self.log('started the oem application for simulation')
        else:
            self.oem_process = Process(target=run_hamilton_process, args=())
            self.oem_process.start()
            self.log('started the oem process')
        self.server_thread = HamiltonInterface.HamiltonServerThread(self.address, self.port)
        self.server_thread.start()
        self.log('started the server thread')
        self.active = True

    def stop(self):
        if not self.active:
            return
        try:
            if self.simulate:
                self.log('sending end run command to simulator')
                try:
                    self.wait_on_response(self.send_command(command='end', id=hex(0)), timeout=1.5)
                except HamiltonTimeoutError:
                    pass
            else:
                for i in range(2):
                    try:
                        os.kill(self.oem_process.pid, signal.SIGTERM)
                        self.log('sent sigterm to oem process')
                        self.oem_process.join()
                        self.log('oem process exited')
                        break
                    except PermissionError:
                        self.log('permission denied, trying again...', 'warn')
                        time.sleep(2)
                else:
                    self.log('Could not kill oem process, moving on with shutdown', 'warn')
        finally:                
            self.active = False
            self.server_thread.disconnect()
            self.log('disconnected from server')
            time.sleep(.1)
            if not self.server_thread.has_exited():
                self.log('server did not exit yet, sending dummy request to exit its loop')
                session = requests.Session()
                adapter = requests.adapters.HTTPAdapter(max_retries=20)
                session.mount('http://', adapter)
                session.get('http://' + HamiltonInterface.default_address + ':' + str(HamiltonInterface.default_port))
                self.log('dummy get request sent to server')
            self.server_thread.join()
            self.log('server thread exited')

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, type, value, tb):
        self.stop()

    def is_open(self):
        return self.active

    def send_command(self, template=None, block_until_sent=False, *args, **cmd_dict): # returns unique id of command
        if not self.is_open():
            self.log_and_raise(RuntimeError('Cannot send a command from a closed HamiltonInterface'))
        if template is None:
            if 'command' not in cmd_dict:
                self.log_and_raise(ValueError('Command dicts from HamiltonInterface must have a \'command\' key'))
            cmd_name = cmd_dict['command']
            if cmd_name in HamiltonInterface.known_templates:
                # raises if this is a known command but some fields in cmd_dict are invalid
                send_cmd_dict = HamiltonInterface.known_templates[cmd_name].assemble_cmd(**cmd_dict)
            else:
                send_cmd_dict = cmd_dict
        else:
            send_cmd_dict = template.assemble_cmd(**cmd_dict)
        if 'id' not in send_cmd_dict:
            self.log_and_raise(ValueError("Command dicts sent from HamiltonInterface must have a unique id with key 'id'"))
        self.server_thread.server_handler_class.send_str(json.dumps(send_cmd_dict))
        if block_until_sent:
            self._block_until_sq_clear()
        return send_cmd_dict['id']

    def wait_on_response(self, id, timeout=0, raise_first_exception=False):
        if timeout:
            start_time = time.time()
        else:
            start_time = float('inf')

        while time.time() - start_time < timeout:
            try:
                response_tup = self.pop_response(id, raise_first_exception)
            except KeyError:
                time.sleep(.1)
                continue
            return response_tup
        self.log_and_raise(HamiltonTimeoutError('Timed out after ' + str(timeout) + ' sec while waiting for response id ' + str(id)))

    def pop_response(self, id, raise_first_exception=False):
        """
        Raise KeyError if id has no matching response. If there is a response, remove it and return a 2-tuple:
            [0] parsed response block dict from Hamilton as in parse_hamilton_return
            [1] Error map: dict mapping int keys (data block Num field) that had exceptions, if any,
                to an exception that was coded in block; {} if no error
        """
        try:
            response = self.server_thread.server_handler_class.pop_response(id)
        except KeyError:
            raise KeyError('No Hamilton interface response indexed for id ' + str(id))
        errflag, blocks = self.parse_hamilton_return(response)
        err_map = {}
        if errflag:
            for blocknum in sorted(blocks.keys()):
                errcode = blocks[blocknum][_block_mainerrfield]
                if errcode != 0:
                    self.log('Exception encoded in Hamilton return.', 'warn')
                    try:
                        decoded_exception = HAMILTON_ERROR_MAP[errcode]()
                    except KeyError:
                        self.log_and_raise(InvalidErrCodeError('Response returned had an unknown error code: ' + str(errcode)))
                    self.log('Exception: ' + repr(decoded_exception), 'warn')
                    if raise_first_exception:
                        self.log('Raising first exception.', 'warn')
                        raise decoded_exception
                    err_map[blocknum] = decoded_exception
        return blocks, err_map

    def _block_until_sq_clear(self):
        while HamiltonServerHandler.has_queued_cmds():
            pass

    def parse_hamilton_return(self, return_str):
        """
        Return a 2-tuple:
            [0] errflag: any error code present in response
            [1] Block map: dict mapping int keys to:
                    dicts with str keys (MainErr, SlaveErr, RecoveryBtnId, StepData, LabwareName, LabwarePos)

        Result value 3 is the field that is returned by the OEM interface.
        "Result value 3 contains one error flag (ErrFlag) and the block data package."
        
        Data Block Format Rules

            The error flag is set once only at the beginning of result value 3. The error flag
            does not belong to the block data but may be used for a simpler error recovery.
            If this flag is set, an error code has been set in any of the block data entries.

            Each block data package starts with the opening square bracket character '['

            The information within the block data package is separated by the comma delimiter ','

            Block data information may be empty; anyway a in block; {} if me() - star   den
   empty]nblf.The infacka[ck;Ploc)     oErrFla- ys,wror if id hae.up.cpf(          )en
   empty]n data package is separn
   empty]nblf.hae.ent in response
     fterStela- y is separa(          robe heHxFanSe u nse_ ent'', # leaetc.)._send)

        def doty]nblf.hotraimatimeaber oft inackae = l flae in Hy is separaeAftescrib            return _ enthelp id bwareIds   en
   empty]nblf. dict m    def doty]nblf. diced for a simurn 'diccur'1'*(id)Blo
    en
   empty]nblf.ping int    def doty]nblf.Dett):
ed for a simoffterStela-sing a(     d1,  nse_,d) th    tc.)._s    def doty]neys to:
        def doty]nblf.eys to:murn 'dpler erroerror,  m_windoe in d foren
   empty]nblf.p       ent in response
     fterStela- y is separ,          barrcoderor,     channelirateModd  tc.n
   empty]nblf.blf.hotraimatimeaber oft inackae = l flae in Hy is separaeAftescrib            return _ enthelp id bwareIds   en
   empty]nblf.    dicts w   empty]nblf.blf.    dicove. Labwerror if youen
   empty]nblf.    diceys   empty]nblf.blf.Urror if yout'', # le.
            pailton_serv_handptionamiltod for_sq_clear(self):msguilt time.sleeamilt  except Kr code: 'ued_cmds():y get request sent to smsgcepd for:
             elf.loocks, er  def Pmilt KeyErmsg (MainErr, SlException encoded num] =nack       th key 'inse_str)d_cmds():['s   -r)d_cm1'command'] +  = self.server_thread.server_handlenamiltod for_shread.servton internum] =nack    .split( bl)ainErr, SlException encoded eturn_s()
   rr_map Hamilt)e = bmmand'] +  = self       if thread.server_handlenamiltod for_shrhread.servton in
claesponse)flag, blocks =ma od for_       'warn')
      rn(respon      exceptiommand']
      r', 'Rup.nternum] =   .split( ,'      self.log('dilen(r', 'Rup.n)e = len(   pass

_)HamiltonServerHandler.innamiltod for_shread.servog('Exception encoded in Hnum] =s.get('PRequr', ':cast(up.) rn(rnerrfiecast       exzip(   pass

_Num'
_blr', 'Recove, r', 'Rup.nd_cmd = {'co] +  = self       if thread.server_handler.innamiltod for_shread.servog('ad.servers.get('Pin sorted(blocks.keyse = blocks[blocknum][_blma od for_       server_address = (ton in
claesponse)[servers.get('P Hamick_numfield = ')]ternum] =s.get('P, blocks = self.parse = ma od for_    thread.server_handlenamiltod for_shrhread.serv
     'No Hamilton in
claesponse)    self.stop(t_
  dirhas_que
  dirtart()
        r  self.oe           L self(_     __)rt()
        r  self.p(tLloat(        INFO)rt()
    hdlf.oe        F):ew_hamil
  dirt')
      rn(m(inte.oe        Fn(m(inte( b%(asc    )s] %(    )s %(float    )s %(mdow_ha)IGTERM)
    hdlf.p(tFn(m(inte(rn(m(inte)rt()
        r  self.addew_hamilhdlf)rt()
        r_d'")_       se_shread.  self.stoto sas_quemsgcemsgRecov=rt_to'tart()
        r  srings, not ' +(msgcemsgRecov))rt()
        r_d'")_       se_shrr_map[blockd'")_       se_    self.logger = None
  self.nd a command from a cl   [0] parsed re
   c�t usesembd for::    r  self.d for,
                       ption::    r  self.tion,
                       pdebug::    r  self.debug,
                       pt_to':    r  self.t_to,
                       pcritical':    r  self.critical}       return bl    r  srings,q_clear(self):msgcemsgRecovterface   srings, Hamilt_clear(self):
   c�t us     msgRecov   wmil),     r  self.t_to)rmsg  # pri('PRif any  snteghop(thrr_map[bloc
            as_qued ftart()
        r  s(de: 'd ftcepd for:
         elf.loent                                                                       