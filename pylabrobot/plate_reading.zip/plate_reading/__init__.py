from __future__ import annotations

import importlib
import sys
import types
import warnings
from typing import Any, Dict

_DEPRECATED_MODULE_ALIASES: Dict[str, str] = {
    # Agilent BioTek (old -> new)
    "pylabrobot.plate_reading.agilent_biotek_backend":
        "pylabrobot.plate_reading.agilent.agilent_biotek_backend",
    "pylabrobot.plate_reading.agilent_biotek_cytation_backend":
        "pylabrobot.plate_reading.agilent.agilent_biotek_cytation_backend",
    "pylabrobot.plate_reading.agilent_biotek_synergyh1_backend":
        "pylabrobot.plate_reading.agilent.agilent_biotek_synergyh1_backend",

    # Molecular Devices (old -> new)
    "pylabrobot.plate_reading.molecular_devices_backend":
        "pylabrobot.plate_reading.molecular_devices.molecular_devices_backend",
    "pylabrobot.plate_reading.molecular_devices_spectramax_m5_backend":
        "pylabrobot.plate_reading.molecular_devices.molecular_devices_spectramax_m5_backend",
    "pylabrobot.plate_reading.molecular_devices_spectramax_384_plus_backend":
        "pylabrobot.plate_reading.molecular_devices.molecular_devices_spectramax_384_plus_backend",
}

def _install_deprecated_module_aliases() -> None:
    for old_name, new_name in _DEPRECATED_MODULE_ALIASES.items():
        if old_name in sys.modules:
            continue

        proxy = types.ModuleType(old_name)
        proxy.__dict__["__package__"] = old_name.rpartition(".")[0]

        _loaded: dict[str, Any] = {"mod": None, "warned": False}

        def _load(_new=new_name, _old=old_name) -> Any:
            if _loaded["mod"] is None:
                if not _loaded["warned"]:
                    warnings.warn(
                        f"{_old} is deprecated; use {_new} instead.",
                        DeprecationWarning,
                        stacklevel=3,
                    )
                    _loaded["warned"] = True
                _loaded["mod"] = importlib.import_module(_new)
                # optional: cache attrs so subsequent access is fast
                proxy.__dict__.update(_loaded["mod"].__dict__)
            return _loaded["mod"]

        def __getattr__(name: str) -> Any:
            mod = _load()
            return getattr(mod, name)

        def __dir__() -> list[str]:
            mod = _load()
            return sorted(set(dir(mod)))

        proxy.__getattr__ = __getattr__  # type: ignore[attr-defined]
        proxy.__dir__ = __dir__          # type: ignore[assignment]

        sys.modules[old_name] = proxy

_install_deprecated_module_aliases()

from .agilent import *
from .bmg_labtech import *
from .molecular_devices import *

from .chatterbox import PlateReaderChatterboxBackend
from .image_reader import ImageReader
from .imager import Imager
from .plate_reader import PlateReader
from .standard import (
  Exposure,
  FocalPosition,
  Gain,
  ImagingMode,
  ImagingResult,
  Objective,
)
